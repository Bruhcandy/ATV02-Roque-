const resultadoDiv = document.getElementById("resultado");
        function impar (){
      
      for (let i = 1; i <= 50; i++) {
       
        if (i % 2 !== 0) {
          
          const numeroParagrafo = document.createElement("p");
          numeroParagrafo.classList.add("numero");
          numeroParagrafo.textContent = i;
          resultadoDiv.appendChild(numeroParagrafo);
        }
      }
    
    }