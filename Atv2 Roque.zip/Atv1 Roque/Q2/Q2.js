const form = document.querySelector('form');
      form.addEventListener('submit', function(event) {
        event.preventDefault();
        const username = this.elements.username.value;
        const password = this.elements.password.value;

        
        if (password === username) {
          const error = document.createElement('p');
          error.textContent = 'Erro: A senha não pode ser igual ao nome de usuário.';
          error.classList.add('error');
          this.insertBefore(error, this.lastElementChild);
        } else {
          const error = document.querySelector('.error');
          if (error) {
            error.remove();
          }

          const name = prompt('Digite seu nome:');
          const age = parseInt(prompt('Digite sua idade:'));
          const salary = parseFloat(prompt('Digite seu salário:'));
          const sex = prompt('Digite seu sexo (f/m):');
          const maritalStatus = prompt('Digite seu estado civil (s/c/v/d):');

      
          if (name.length <= 3) {
            alert('Erro: O nome deve ter mais de 3 caracteres.');
          } else if (age < 0 || age > 150) {
            alert('Erro: A idade deve estar entre 0 e 150 anos.');
          } else if (salary <= 0) {
            alert('Erro: O salário deve ser maior que zero.');
          } else if (sex !== 'f' && sex !== 'm') {
            alert('Erro: O sexo deve ser "f" ou "m".');
          } else if (!['s', 'c', 'v', 'd'].includes(maritalStatus)) {
            alert('Erro: O estado civil deve ser "s", "c", "v" ou "d".');
          } else {
            alert('Informações validadas com sucesso!');
          }
        }
      });