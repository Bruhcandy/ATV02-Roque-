const formulario = document.getElementById("formulario");
      const resultadoDiv = document.getElementById("resultado");

      formulario.addEventListener("submit", function(event) {
        event.preventDefault();

        
        const numeros = [
          Number(document.getElementById("numero1").value),
          Number(document.getElementById("numero2").value),
          Number(document.getElementById("numero3").value),
          Number(document.getElementById("numero4").value),
          Number(document.getElementById("numero5").value)
        ];

      
        const soma = numeros.reduce((acc, num) => acc + num, 0);

        
        const media = soma / numeros.length;

        
        resultadoDiv.innerHTML = `<p id="mensagem">A soma é ${soma}. A média é ${media}.</p>`;
      });