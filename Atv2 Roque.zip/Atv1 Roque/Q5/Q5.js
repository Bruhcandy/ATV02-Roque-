const numbersDiv = document.getElementById("numbers");


function pe(){
for (let i = 1; i <= 20; i++) {
    document.write(i + "<br>");
  }
}

function deitado(){    
      for (let i = 1; i <= 20; i++) {
        const number = document.createElement("span");
        number.classList.add("number");
        number.textContent = i;
        numbersDiv.appendChild(number);
      }}