function validarNota() {
    var nota = document.getElementById("nota").value;
    if (nota < 0 || nota > 10 || isNaN(nota)) {
      document.getElementById("mensagem").innerHTML = "Nota inválida. Digite um valor entre 0 e 10.";
    } else {
      document.getElementById("mensagem").innerHTML = "Nota válida.";
    }
  }