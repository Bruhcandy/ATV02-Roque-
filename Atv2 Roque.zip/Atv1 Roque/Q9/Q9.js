const resultadoDiv = document.getElementById("resultado");

      function exibirNumeros() {
        resultadoDiv.innerHTML = "";

        const numero1 = parseInt(document.getElementById("numero1").value);
        const numero2 = parseInt(document.getElementById("numero2").value);

        if (isNaN(numero1) || isNaN(numero2)) {
          resultadoDiv.innerHTML = "Digite dois números inteiros.";
          return;
        }

        if (numero1 > numero2) {
          resultadoDiv.innerHTML = "O primeiro número deve ser menor ou igual ao segundo.";
          return;
        }

        
        for (let i = numero1; i <= numero2; i++) {
          const numeroParagrafo = document.createElement("p");
          numeroParagrafo.classList.add("numero");
          numeroParagrafo.textContent = i;
          resultadoDiv.appendChild(numeroParagrafo);
        }
      }