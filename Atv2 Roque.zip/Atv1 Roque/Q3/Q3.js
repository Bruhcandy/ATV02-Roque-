function calcular() {
    
    const popA = parseInt(document.getElementById("popA").value);
    const taxaA = parseFloat(document.getElementById("taxaA").value) / 100;
    const popB = parseInt(document.getElementById("popB").value);
    const taxaB = parseFloat(document.getElementById("taxaB").value) / 100;

    
    if (isNaN(popA) || isNaN(taxaA) || isNaN(popB) || isNaN(taxaB)) {
        alert("Por favor, informe valores válidos.");
        return;
    }

    
    let anos = 0;
    while (popA < popB) {
        popA *= 1 + taxaA;
        popB *= 1 + taxaB;
        anos++;
    }

   
    document.getElementById("resultado").innerHTML = `Serão necessários ${anos} anos para que a população do país A ultrapasse ou iguale a população do país B.`;
}